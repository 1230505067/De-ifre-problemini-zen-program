#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
printf("Dosya sifrelemek icin : 1\nSifreli dosyayi acmak icin : 2\nout.txt(sifreli dosyayi) silmek icin : 3\n(Sifreleme islemi oncesinde dosyasini silin!!!\nDosyayi sildikten sonra sifreleme islemini 2 kez yapiniz.)\n");
	int secenek;
	 scanf("%d",&secenek); 
	 
	 if(secenek==1){
	 printf("Sifreleme anahtarini giriniz :");
	 	int anahtar;
	 scanf("%d",&anahtar);
	char ch;
	FILE* fp;
	FILE* file;
	/*   //BU SATIRLAR A�ILIRSA ��FRES�Z MET�N YAZDIRILIR...
	fp = fopen("C:/Users/Monster/OneDrive/Masa�st�/odev/input 1.txt", "r");
	while (!feof(fp)) {
		ch = getc(fp);	
		printf("%c", ch);	
		}
		*/
	/*	dosya okuyan pointer sona geldi tekrar okuma i�lemini ba�latarak pointer�n ba�a gelmesini sa�l�yorum */
fp = fopen("input 1.txt", "r");//DOSYA SADECE OKUMA MODUNDA A�ILDI
		printf("SIFRELI METIN : ");
		file=fopen("out.txt","a");//DOSYA SADECE EKLEME MODUNDA A�ILDI
	while (!feof(fp)) {              //BU D�NG� �LE ��FRELENECEK DOSYANIN SONUNA KADAR �LERL�YORUM...
		ch = getc(fp);               //DOSYAYI OKUDUM
		int a=isalpha(ch);          //ALFABEYE DAH�L M�?

		if(a!=0){                   //ALFABET�K B�R KARAKTER �SE 
			ch=tolower(ch);        //K���K HARFE D�N��T�R
			ch=ch-'a';            //KARAKTERDEN A �IKAR
		          
		ch +=anahtar;//ANAHTARI EKLE
		ch%=26; //ALFABEDE BULUNAN KARAKTER SAYISI �LE MODUNU AL
		ch +='a';//�IKARILAN A YI ��FRELEMEDEN SONRA TEKRAR EKLE
			printf("%c",ch); //EKRANA YAZDIR
			
			fprintf(file,"%c",ch);//DOSYAYA YAZDIR
		}
		else{// E�ER ALFABET�K KARAKTER DE��LSE BO�LUK OLDU�UNU VAR SAYIYORUZ...
		
			char bosluk=32;
				printf("%c",bosluk);//EKRANA YAZDIR
		
				fprintf(file,"%c",bosluk);//DOSYAYA YAZDIR
		}


	}
getch();}

else if(secenek==2){   //�ifre ��zme se�ene�i
	 printf("Sifreyi cozmek icin anahtarini giriniz :");
	 	int anahtar;
	 scanf("%d",&anahtar);//E�ER KULLANICI ANAHTARI B�L�YORSA DOSYAYI A�AL�R...
	 char ch;
	FILE* sifreli; //DOSYALAR ���N PO�NTER'LAR OLU�TURULDU
	FILE* acik;
	sifreli = fopen("out.txt", "r");//DOSYA SADECE OKUMA MODUNDA A�ILDI
	
		acik=fopen("�ifre_cozulmus_metin.txt","a");//DOSYA SADECE EKLEME MODUNDA A�ILDI
	while (!feof(sifreli)) {              //BU D�NG� �LE ��FRELENECEK DOSYANIN SONUNA KADAR �LERL�YORUM...
		ch = getc(sifreli);               //DOSYAYI OKUDUM
		int a=isalpha(ch);          //ALFABEYE DAH�L M�?

		if(a!=0){                   //ALFABET�K B�R KARAKTER �SE 
			ch=tolower(ch);        //K���K HARFE D�N��T�R
			ch=ch-'a';            //KARAKTERDEN A �IKAR
		          
		ch -=anahtar;//ANAHTARI CIKAR ��NK� ��FRELERKEN TAM TERS�N� YAPMI�TIK
		ch%=26;
		ch +='a';
			printf("%c",ch);//EKRANA YAZDIRIR
			
			fprintf(acik,"%c",ch);//DOSYAYA YAZDIRIR
		}
		else{
		
			char bosluk=32;
				printf("%c",bosluk);//EKRANA YAZDIRIR
		
				fprintf(acik,"%c",bosluk);//DOSYAYA YAZDIRIR
		}


	}
getch();////////////
}

else if(secenek==3){
	int sonuc = remove("out.txt");//DOSYAYI S�LER

  if(sonuc == 0){
    fprintf(stdout, "Dosya silindi");
  } else {
    fprintf(stderr, "Dosya silinemedi");
    return -1;
  }

	
	
}

return 0;
}
